#include <iostream>
#include <fstream>
#include <sstream>
#include <strings.h>
using namespace std;

// classes implementations
string array[50];
// linked list start

class node
{
public:
	string data;
	node *next;

	node()
	{
		this->data = "";
	}
};

class linkedlist
{
public:
	node *head;
	node *tail;

	linkedlist()
	{
		head = NULL;
		tail = NULL;
	}
	// TASK 2
	void insertEND(string d)
	{
		// constructing new node
		node *temp = new node;
		temp->data = d;
		temp->next = NULL;
		// checking if list is empty
		if (head == NULL)
		{
			head = temp;
			tail = temp;
		}
		else
		{
			node *temp1 = head;
			while (temp1->next != NULL)
			{
				temp1 = temp1->next;
			}

			temp1->next = temp;
			temp->next = NULL;
			tail = temp;
		}
	}

	void insertBEG(string d)
	{
		node *temp = new node;
		temp->data = d;
		temp->next = head;
		head = temp;
	}

	void delEnd(node *h)
	{
		node *curr = new node;
		node *prev = new node;
		curr = h;
		while (curr->next != NULL)
		{
			prev = curr;
			curr = curr->next;
		}
		prev->next = NULL;
		tail = prev;
		delete curr;
	}

	void delSelected(string dt)
	{
		node *curr = new node;
		node *prev = new node;
		curr = head;

		while (curr->next != NULL)
		{
			if (curr->data == dt)
			{
				break;
			}

			prev = curr;
			curr = curr->next;
		}
		prev->next = curr->next;
		delete curr;
	}

	int linkedlistSIZE(node *h)
	{
		node *temp = new node;
		temp = h;
		int count = 0;
		while (temp != NULL)
		{
			count++;
			temp = temp->next;
		}
		return count;
	}

	void display()
	{
		int i = 1;
		node *d = new node;
		d = head;
		if (head == NULL)
		{
			cout << "EMPTY LIST" << endl;
			return;
		}
		while (d != NULL)
		{
			cout << d->data << endl;
			d = d->next;
			i++;
		}
	}
};

// linked list endd

// stack string
class stacknode
{
public:
	string data;
	stacknode *link;

	stacknode()
	{
		this->data = "";
		this->link = NULL;
	}
};

class stack
{
	stacknode *top;

public:
	stack()
	{
		top = NULL;
	}

	// functions
	void push(string data)
	{
		stacknode *temp = new stacknode;
		temp->data = data;
		temp->link = top;
		top = temp;
	}

	void pop()
	{
		stacknode *temp = new stacknode;

		if (top == NULL)
		{
			cout << endl
				 << "EMPTY STACK" << endl;
		}
		else
		{
			temp = top;
			top = top->link;
			delete[] temp;
		}
	}

	void insertTEN(stack &obj)
	{
		string tem = "";
		for (int i = 0; i < 10; i++)
		{
			cout << "ENTER ELEMENT NO[" << i + 1 << "]? : ";
			cin >> tem;
			obj.push(tem);
			tem = "";
		}
	}

	void forwardDisplay()
	{
		stacknode *t = new stacknode;
		t = top;
		int i = 0;
		string array[100];

		if (t == NULL)
		{
			cout << endl
				 << "EMPTY STACK" << endl;
		}
		cout << endl
			 << endl;
		while (t != NULL)
		{
			array[i] = t->data;
			i++;
			t = t->link;
		}

		cout << "STACK IN FORWARD ORDER : " << endl;
		for (int j = i - 1; j >= 0; j--)
		{
			cout << array[j] << endl;
		}
	}

	void display()
	{
		stacknode *t = new stacknode;
		t = top;

		if (t == NULL)
		{
			cout << endl
				 << "EMPTY STACK" << endl;
		}
		cout << endl
			 << endl;
		while (t != NULL)
		{
			cout << t->data << endl;
			t = t->link;
		}
	}

	linkedlist data()
	{
		linkedlist l1;
		stacknode *t = new stacknode;
		t = top;

		if (t == NULL)
		{
			cout << endl
				 << "EMPTY STACK" << endl;
		}
		cout << endl
			 << endl;
		while (t != NULL)
		{
			l1.insertBEG(t->data);
			t = t->link;
		}
		return l1;
	}
};

// stack string endd

// functions declarations
void starter();

// functions implementation

void starter()
{
	string ffname = "";
	string extra = ".txt";
	string filename = "";
	string a, b, c;
	stack backer;
	char opt31, opt32, ch;
	string t;
mm:
b:	
	cin.sync();
	system("CLS");
agg:
	cin.sync();	
	ifstream temp("files.txt");
	ifstream folder;
	cout << "Welcome To FZ File Explorer!!!";
	cout << endl;
	cout << "1)This PC" << endl
		 << "2)Shutdown" << endl
		 << "Please Select From The Given Options : ";
	cin >> ch;

	int i = 0, j = 0;
	// sfirst
	switch (ch)
	{
	case '1':
	case 'a':
	case 'A':
	{
		string arraymain[5];
		system("CLS");
		cout<<"THIS PC[DIRECTORIES]"<<endl<<endl;
		while (getline(temp, t))
		{
			arraymain[i] = t;
			i++;
			cout << i << ") " << t << endl;
		}
		temp.close();

		cout << "Please Select From The Given Options : ";
		cin >> opt31; // 31 just to randomize var name

		// s2ndd
		switch (opt31)
		{
		case '1':
		case 'a':
		case 'A':

			system("CLS");
			cout << "THIS PC >> " << arraymain[0] << endl
				 << endl;
			filename = arraymain[0] + extra;
			folder.open(filename.c_str());
			while (getline(folder, t))
			{
				array[j] = t;
				j++;
				cout << j << ")" << t << endl;
			}
			cout << "Please Select From The Given Options : ";
			cin >> opt32;

			// s3rd
			switch (opt32)
			{
			case '1':
			case 'a':
			case 'A':
			{
				char opt33;
				string fname = array[0] + extra;
				string baba;
				ifstream hell(fname.c_str());
			buck:
			cin.sync();	
				system("CLS");
				cout << "THIS PC >> " << arraymain[0] << " >> " << array[0] << endl
					 << endl;

				while (getline(hell, baba))
				{
					cout << baba << endl;
				}
				hell.close();
				cout << endl
					 << endl
					 << "THIS IS THE EXTRACTED TEXT FROM FILE YOU OPENED[" << fname << "] , Which Operations You want to perform?" << endl<<endl;
				cout << "1)Rename File" << endl
					 << "2)Delete File" << endl
					 << "3)Update File Data" << endl
					 << "4)Add New Folder"<<endl
					 << "5)Make Copy Of File[Shortcut]"<<endl;
				cout << "Please Select From The Given Options? : ";
				cin >> opt33;

				// s4start
				//RENAMING
				switch (opt33)
				{
				case '1':
				case 'a':
				case 'A':
				{
					string nname;
					system("CLS");
					cout << "Current File Name : " << fname << endl;
					cout << "Enter New Name For Your File? : ";
					cin >> nname;

					char xD;
					system("CLS");
					cout << "Is The New Name[" << nname << "]? " << endl
						 << "1)Yes Confirm!" << endl
						 << "2)No" << endl;
					cout << "Please Select From The Given Options? : ";
					cin >> xD;

					// s5start

					switch (xD)
					{
					case '1':
					case 'a':
					case 'A':
					{
						stack s1;
						string imp;
						ifstream lol(fname.c_str());
						string newfilename = nname + extra;
						system("CLS");
						ofstream lol1(newfilename.c_str(), ios::trunc);

						while (getline(lol, imp))
						{
							lol1 << imp << endl;
						}

						string st = arraymain[0] + extra;
						string str = "";
						ifstream ifs(st.c_str());
						while (getline(ifs, str))
						{
							s1.push(str);
						}
						linkedlist storer = s1.data();
						storer.delSelected(array[0]);

						ifs.close();
						lol.close();
						lol1.close();
						remove(fname.c_str());

						ifstream ifson(st.c_str());
						ofstream ifso("temp.txt", ios::trunc);
						string tte;

						while (getline(ifson, tte))
						{
							if (tte != array[0])
							{
								ifso << tte << endl;
							}
						}

						ifson.close();
						ifso.close();

						remove(st.c_str());

						ifstream ifso1("temp.txt");
						ofstream ifso2(st.c_str(), ios::trunc);

						while (getline(ifso1, tte))
						{
							ifso2 << tte << endl;
						}

						ifso1.close();
						ifso2.close();
						remove("temp.txt");

						ifso2.open(st.c_str(), ios::app);
						ifso2 << nname;
						ifso2.close();
						char opop12;
					wre:
						cout << "File Renamed Successfully." << endl
							 << "1) Back" << endl
							 << "2) Main Menu" << endl
							 << "3) Shutdown" << endl;
						cout << "Please Select From The Given Options? : ";
						cin >> opop12;

						if (opop12 == '1' || opop12 == 'A' || opop12 == 'a')
						{
							goto buck;
						}
						else if (opop12 == '2' || opop12 == 'B' || opop12 == 'b')
						{
							goto mm;
						}
						else if (opop12 == '3' || opop12 == 'c' || opop12 == 'C')
						{
							exit(0);
						}
						else
						{
							system("CLS");
							cout << endl
								 << "You Have Selected Wrong Option , Please Select From The Following Options[1 Or 2 Or 3]" << endl
								 << endl;
							system("CLS");
							goto wre;
						}
					}
					break;

					case '2':
					case 'b':
					case 'B':
					{
						// to be written
					}
					break;
					}

					// s5endd
				}
				break;
				
				//DELETION
				case '2':
				case 'b':
				case 'B':
				{
					stack s1;
					linkedlist l1;
					system("CLS");
					string str = "";
					ifstream opp(fname.c_str());

					while (getline(opp, str))
					{
						s1.push(str);
					}
					opp.close();
					char opop;
					l1 = s1.data();
					system("CLS");
					cout << "File[" << fname << "] Removed Successfully." << endl
						 << "1) Undo" << endl
						 << "2) Confirm Your Action[Once Confirmed Can Not Be Retrieved]";
					cout << "Please Select From The Given Options? : ";
					cin >> opop;
					remove(fname.c_str());
					// s6start
					switch (opop)
					{
					case '1':
					case 'A':
					case 'a':
					{
						node *h = l1.head;
						ofstream opp1(fname.c_str(), ios::trunc);
						while (h!= NULL)
						{
							opp1 << h->data << endl;
							h = h->next;
						}

						opp1.close();

						char abcd;

						system("CLS");
						cout << "File Retrieved Successfully" << endl;
						cout << "1) Main Menu" << endl
							 << "2) Shutdown" << endl;
						cout << "Please Select From The Given Options? : ";
						cin >> abcd;
						if (abcd == '1' || abcd == 'A' || abcd == 'a')
						{
							goto mm;
						}
						else if (abcd == '2' || abcd == 'B' || abcd == 'b')
						{
							exit(0);
						}
						else if (abcd == '3' || abcd == 'c' || abcd == 'C')
						{
							goto b;
						}
						else
						{
							system("CLS");
							cout << endl
								 << "You Have Selected Wrong Option , Please Select From The Following Options[1 Or 2 Or 3]" << endl
								 << endl;
							goto wr;
						}
					}
					break;

					case '2':
					case 'B':
					case 'b':
					{

					wr:
						cin.sync();
						stack s1;
						linkedlist l2;
						char dd;
						string str, tep;
						ffname = arraymain[0] + extra;
						ifstream remo(ffname.c_str());
						while (getline(remo, str))
						{
							if (str != array[0])
							{
								s1.push(str);
							}
						}
						remo.close();
						remove(ffname.c_str());
						l2 = s1.data();
						node *h = l2.head;
						ofstream remod(ffname.c_str(), ios::trunc);
						while (h != NULL)
						{
							remod << h->data << endl;
							h = h->next;
						}
						remod.close();

						system("CLS");
						cout << "File Permentantly Deleted" << endl;
						cout << "1) Main Menu" << endl
							 << "2) Shutdown" << endl
							 << "3) BACK" << endl;
						cout << "Please Select From The Given Options? : ";
						cin >> dd;
						if (dd == '1' || dd == 'A' || dd == 'a')
						{
							goto mm;
						}
						else if (dd == '2' || dd == 'B' || dd == 'b')
						{
							exit(0);
						}
						else if (dd == '3' || dd == 'c' || dd == 'C')
						{
							goto b;
						}
						else
						{
							system("CLS");
							cout << endl
								 << "You Have Selected Wrong Option , Please Select From The Following Options[1 Or 2 Or 3]" << endl
								 << endl;
							goto wr;
						}
					}
					break;
					}
					// s6endd
				}
				break;

				case '3':
				case 'C':
				case 'c':
				{
					system("CLS");
				wrd:
				bbb:
				bacc:
					cin.sync();
					cout << "This Is The Extracted Data From File [" << fname << "]? " << endl
						 << endl;
					ifstream filed(fname.c_str());
					string str = "";
					char opd;
					while (getline(filed, str))
					{
						cout << str << endl;
					}
					filed.close();
					cout << endl
						 << "How You Want To Update File [" << fname << "]?" << endl;
					cout << "1) Add New Data" << endl
						 << "2) Clear File Data" << endl;
					cout << "Pleas Select From The Given Options? : ";
					cin >> opd;

					if (opd == '1' || opd == 'A' || opd == 'a')
					{
						stack s1;
						linkedlist l1;
						string str33;
						cin.sync();
						cout << "Enter New Data You Want To Add In File[" << fname << "]? : ";
						getline(cin, str33);

						string strr33;
						ifstream abcdef(fname.c_str());
						while (getline(abcdef, strr33))
						{
							s1.push(strr33);
						}
						abcdef.close();

						ofstream abcde(fname.c_str(), ios::app);
						abcde 
							  << str33;
						abcde.close();

						system("CLS");
						cout << "File Updated Succesfully" << endl;
						cout << "This Is Updated Text From File[" << fname << "], Please Review." << endl;

						ifstream abcefg(fname.c_str());
						while (getline(abcefg, str33))
						{
							cout << str33 << endl;
						}
						abcefg.close();

						char ddl;
					wrdeen:
						cin.sync();
						cout << endl
							 << endl
							 << " 1)Undo" << endl
							 << " 2)Confirm And Save" << endl;
						cin >> ddl;
						if (ddl == 'A' || ddl == 'a' || ddl == '1')
						{
							system("CLS");
							l1 = s1.data();
							ofstream hhh(fname.c_str(), ios::trunc);
							node *h = l1.head;

							while (h != NULL)
							{
								hhh << h->data << endl;
								h = h->next;
							}

							hhh.close();

							cout << "New Added Data is Removed From file .This is the extracted text from file after undo changes" << endl
								 << endl;
							ifstream hhhh(fname.c_str());
							string str44;
							while (getline(hhhh, str44))
							{
								cout << str44 << endl;
							}
							hhh.close();
						wrdeec:
							cin.sync();
							char ch44;
							cout << "What you want to do now? : " << endl;
							cout << " 1)Back" << endl
								 << " 2)Main Menu" << endl
								 << " 3)Shutdown" << endl;
							cout << "Please Select From Given Options? : ";
							cin >> ch44;

							if (ch44 == 'A' || ch44 == '1' || ch44 == 'a')
							{
								system("CLS");
								goto bacc;
							}
							else if (ch44 == 'B' || ch44 == 'b' || ch44 == '2')
							{
								system("CLS");
								goto mm;
							}
							else if (ch44 == '3' || ch44 == 'c' || ch44 == 'C')
							{
								exit(0);
							}
							else
							{
								system("CLS");
								cout << endl
									 << "You Have Selected Wrong Option , Please Select From The Following Options[1 Or 2 Or 3]" << endl
									 << endl;
								goto wrdeec;
							}
						}
						else if (ddl == 'B' || ddl == 'b' || ddl == '2')
						{
							char five;
						wrdee:
							cin.sync();
							cout << endl
								 << endl
								 << "1) Back"<<endl
								 << "2) Main Menu" << endl
								 << "3) Shutdown" << endl;
							cout << "Please Select From Given Options? : ";
							cin >> five;

							if (five == 'A' || five == 'a' || five == '1')
							{
								system("CLS");
								goto bbb;
							}
							else if (five == '2' || five == 'B' || five == 'b')
							{
								system("CLS");
								goto mm;
							}
							else
							{
								system("CLS");
								cout << endl
									 << "You Have Selected Wrong Option , Please Select From The Following Options[1 Or 2]" << endl
									 << endl;
								goto wrdee;
							}
						}
						else
						{
							system("CLS");
							cout << endl
								 << "You Have Selected Wrong Option , Please Select From The Following Options[1 Or 2]" << endl
								 << endl;
							goto wrdeen;
						}
					}
					else if (opd == '2' || opd == 'B' || opd == 'b')
					{
						system("CLS");
						stack s1;
						linkedlist l1;

						ifstream strro(fname.c_str());
						string strrro;
						while (getline(strro, strrro))
						{
							s1.push(strrro);
						}
						strro.close();

						ofstream strroo(fname.c_str(), ios::trunc);
						strroo.close();

						char ch55;
					wrdeec1:
						cin.sync();
						cout << "File Data Removed" << endl;
						cout << "What you want to do now? : " << endl;
						cout << " 1)Back" << endl
							 << " 2)Main Menu" << endl
						 << " 3)Undo" << endl<<" 4)Shutdown"<<endl; 
						cout << "Please Select From Given Options? : ";
						cin >> ch55;

						if (ch55 == 'A' || ch55 == '1' || ch55 == 'a')
						{
							system("CLS");
							goto bacc;
						}
						else if (ch55 == 'B' || ch55 == 'b' || ch55 == '2')
						{
							system("CLS");
							goto mm;
						}
						else if (ch55 == '3' || ch55 == 'c' || ch55 == 'C')
						{
							system("CLS");
							ofstream rev(fname.c_str(),ios::trunc);
							l1=s1.data();
							node *h=l1.head;
							
							while(h!=NULL){
								rev<<h->data<<endl;
								h=h->next;
							}
							rev.close();
							
							cout<<"Data Restored"<<endl<<endl;
							cout << "What you want to do now? : " << endl;
						cout << " 1)Back" << endl
							 << " 2)Main Menu" << endl
						 << " 3)Shutdown"<<endl;
						cout << "Please Select From Given Options? : ";
						cin >> ch55;

						if (ch55 == 'A' || ch55 == '1' || ch55 == 'a')
						{
							system("CLS");
							goto bacc;
						}
						else if (ch55 == 'B' || ch55 == 'b' || ch55 == '2')
						{
							system("CLS");
							goto mm;
						}
						}
						else if(ch55 == '4' || ch55 == 'd' || ch55 == 'D'){
							exit(0);
						}
						else
						{
							system("CLS");
							cout << endl
								 << "You Have Selected Wrong Option , Please Select From The Following Options[1 Or 2 Or 3]" << endl
								 << endl;
							goto wrdeec1;
						}
					}
					else
					{
						system("CLS");
						cout << endl
							 << "You Have Selected Wrong Option , Please Select From The Following Options[1 Or 2]" << endl
							 << endl;
						goto wrd;
					}
				}
				break;
				
				case '4':
				case 'd':
				case 'D':
					{
						string newfolder;	
						system("CLS");
						bckb:
						bckbo:	
						cin.sync();	
						cout<<"Enter New File Name? : ";
						cin>>newfolder;
						
						string newfolderfile=newfolder+extra;
						
						ofstream nnn(newfolderfile.c_str(),ios::trunc);
						nnn.close();
						string kit=arraymain[0]+extra;
						ofstream nnnn(kit.c_str(),ios::app);
						
							nnnn<<endl<<newfolder;
						
						nnnn.close();
						
						char options,options1;
						agggg:
						cin.sync();	
						cout<<"How Would You Like To Enter New File["<<newfolder<<"] Data? : "<<endl;
						cout<<" 1)Leave it empty"<<endl<<" 2)Write Data Now[USER INPUT]"<<endl<<" 3)Copy From Another File"<<endl;
						cout<<"Please Select From Given Options? : ";
						cin>>options;
						
						if(options=='1'||options=='a'||options=='A'){
							system("CLS");
							agge:
							cin.sync();	
							cout<<"Folder Left Empty"<<endl<<"What Would You Like To Do Now? : "<<endl;
							cout<<" 1)Back"<<endl<<" 2)Main Menu"<<endl<<" 3)Shutdown"<<endl;
							cout<<"Please Select From Given Options? : ";
							cin>>options1;
							if(options1=='1'||options1=='a'||options1=='A'){
								system("CLS");
								goto bckb;
							}
							else if(options1=='2'||options1=='B'||options1=='b'){
								system("CLS");
								goto mm;
							}
							else if(options1=='3'||options1=='c'||options1=='C'){
								system("CLS");
								exit(0);
							}
							else{
								system("CLS");
								cout << endl
									 << "You Have Selected Wrong Option , Please Select From The Following Options[1 Or 2]" << endl
									 << endl;
								goto agge;
							}
						}
						
						else if(options=='B'||options=='b'||options=='2'){
							stack s1;
							linkedlist l1;
							char more;
							string strd;
							system("CLS");
							cout<<"Enter File Data? : "<<endl;
							mr:
							cin.sync();
							getline(cin,strd);
							s1.push(strd);
							cout<<"Do You Have More Data? Or Save Entered Data? : "<<endl;
							cout<<" 1)More Data"<<endl<<" 2)Save Entered Data"<<endl;
							cout<<"Please Select From Given Options? : ";
							cin>>more;
							if(more=='1'||more=='A'||more=='a'){
								system("CLS");
								cout<<"Enter More Data? : ";
								goto mr;
							}
							
							l1=s1.data();
							node *h=l1.head;
							
							ofstream nf(newfolderfile.c_str(),ios::app);
							while(h!=NULL){
								nf<<h->data<<endl;
								h=h->next;
							}
							nf.close();
							
							char huhu;
							system("CLS");
							aggen:
							cin.sync();	
							cout<<"Data Saved In Newly Created File["<<newfolder<<"]."<<endl;
							cout<<"What You Want To Do Now? : "<<endl;
							cout<<" 1)Back"<<endl<<" 2)Main Menu"<<endl<<" 3)Shutdown"<<endl;
							cout<<"Please Select From Given Options? : ";
							cin>>huhu;
							
							if(huhu=='1'||huhu=='a'||huhu=='A'){
								system("CLS");
								goto bckbo;
							}
							else if(huhu=='2'||huhu=='B'||huhu=='b'){
								system("CLS");
								goto mm;
							}
							else if(huhu=='3'||huhu=='c'||huhu=='C'){
								system("CLS");
								exit(0);
							}
							else{
								system("CLS");
								cout << endl
									 << "You Have Selected Wrong Option , Please Select From The Following Options[1 Or 2 Or 3]" << endl
									 << endl;
								goto aggen;
							}	
						}	
						else if(options=='3'||options=='c'||options=='C'){
							string fcd;
							stack s1;
							linkedlist l1;
							system("CLS");
							cout<<"Enter File Name? You Want To Copy Data From? : ";
							cin>>fcd;
							string nameoff=fcd+extra;
							
							ifstream cpyy(nameoff.c_str());
							string ttt;
							while(getline(cpyy,ttt)){
								s1.push(ttt);	
							}
							cpyy.close();
							
							system("CLS");
							cout<<"Following Data Is Copied From File ["<<nameoff<<"] To File["<<newfolder<<"]. "<<endl<<endl;
							
							ofstream cpyyd(newfolderfile.c_str(),ios::app);
							l1=s1.data();
							node *h=l1.head;
							
							while(h!=NULL){
								cout<<h->data<<endl;
								cpyyd<<h->data<<endl;
								h=h->next;
							}
							cpyyd.close();
							
							char options12;
							aggenn:
							cin.sync();	
							cout<<endl<<endl<<"What Would You Like To Do Now? : "<<endl;
							cout<<" 1)Back"<<endl<<" 2)Main Menu"<<endl<<" 3)Shutdown"<<endl;
							cout<<"Please Select From Given Options? : ";
							cin>>options12;
							if(options12=='1'||options12=='a'||options12=='A'){
								system("CLS");
								goto bckb;
							}
							else if(options12=='2'||options12=='B'||options12=='b'){
								system("CLS");
								goto mm;
							}
							else if(options12=='3'||options12=='c'||options12=='C'){
								system("CLS");
								exit(0);
							}
							else{
								system("CLS");
								cout << endl
									 << "You Have Selected Wrong Option , Please Select From The Following Options[1 Or 2 Or 3]" << endl
									 << endl;
								goto aggenn;
							}
							
						}	
						
						else{
							system("CLS");
							cout << endl
								 << "You Have Selected Wrong Option , Please Select From The Following Options[1 Or 2]" << endl
								 << endl;
							goto agggg;
						}
					}
				break;
				
				case '5':
				case 'E':
				case 'e':
					{
						string copyfilename=array[0]+" -copy";
						
						string kit=arraymain[0]+extra;
						ofstream nnnn(kit.c_str(),ios::app);
						
							nnnn<<endl<<copyfilename;
						
						nnnn.close();
						
						copyfilename+=extra;	
						system("CLS");
						ofstream copyyy(copyfilename.c_str());
						ifstream copyyy2(fname.c_str());
						string stb;
						
						while(getline(copyyy2,stb)){
							copyyy<<stb<<endl;
						}	
						copyyy2.close();
						copyyy.close();
						
						aggbb:
						cin.sync();	
						char hahaha;
						cout<<"Copy Of File Has Been Created And Saved"<<endl;
						cout<<"What you want do now?"<<endl;
						cout<<" 1)Back"<<endl<<" 2)Main Menu"<<endl<<" 3)Shutdown"<<endl;
						cout<<"Please Select from the given options? : ";
						cin>>hahaha;
						
						
						if(hahaha=='1'||hahaha=='a'||hahaha=='A'){
							system("CLS");
							goto buck;
						}
						else if(hahaha=='2'||hahaha=='B'||hahaha=='b'){
							system("CLS");
							goto mm;
						}
						else if(hahaha=='C'||hahaha=='c'||hahaha=='3'){
							exit(0);
						}
						else{
							system("CLS");
							cout << endl
								 << "You Have Selected Wrong Option , Please Select From The Following Options[1 Or 2]" << endl
								 << endl;
							goto aggbb;	
						}
					}
				break;
				default:
					system("CLS");
						cout << endl
							 << "You Have Selected Wrong Option , Please Select From The Following Options[1 Or 2]" << endl
							 << endl;
						goto agg;
				}
				// s4endd
			}
			break;
			}
			// s3rend
			break;
		}
		// s2nddenddd
		break;
	}
	case '2':
	case 'b':
	case 'B':
		system("CLS");
		cout << "Shutting Down" << endl;
		cout << "Operation Successfull";
		exit(0);
		break;
		
	default:
			system("CLS");
			cout << endl
			<< "You Have Selected Wrong Option , Please Select From The Following Options[1 Or 2]" << endl
			<< endl;
			goto agg;	
	}
	// sfirstendd
}

int main()
{
	starter();
	//	string array[2];
	//		stack s1;
	//		ifstream ff("Local Disk (C).txt");
	//		string str,str1;
	//		while(getline(ff,str)){
	//			s1.push(str);
	//		}
	////		s1.display();
	//
	//		linkedlist l2=s1.data();
	//		l2.display();
	//		cout<<endl<<endl
	//		l2.delSelected(array[0]);
	//		l2.display();
	
	return 0;
}
